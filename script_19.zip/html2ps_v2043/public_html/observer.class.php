<?php

class Observer {
  function run($params) {
    // By default, do nothing
  }
}

?>