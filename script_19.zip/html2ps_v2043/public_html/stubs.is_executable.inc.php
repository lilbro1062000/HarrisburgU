<?php

function is_executable() {
  return true;
}

?>